import { combineReducers } from 'redux'
import statement from './statement'

export default combineReducers({
  statement
})