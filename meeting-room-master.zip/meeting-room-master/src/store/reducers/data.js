export const StatementData = {
  statements: {}
}